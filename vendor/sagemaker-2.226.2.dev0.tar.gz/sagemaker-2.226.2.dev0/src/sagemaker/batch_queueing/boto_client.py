"""The file provides helper function for getting Batch boto client."""

from __future__ import absolute_import
from typing import Optional
import boto3


def get_batch_boto_client(
    region: Optional[str] = None,
    endpoint: Optional[str] = None,
) -> boto3.session.Session.client:
    """Helper function for getting Batch boto3 client.

    Args:
        region: Region specified
        endpoint: Batch API endpoint.

    Returns: Batch boto3 client.

    """
    return boto3.client("sm_batch", region_name=region, endpoint_url=endpoint)
