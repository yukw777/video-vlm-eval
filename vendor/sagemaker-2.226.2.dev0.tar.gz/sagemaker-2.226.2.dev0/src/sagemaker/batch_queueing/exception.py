"""The file Defines customized exception for Batch queueing"""

from __future__ import absolute_import


class NoTrainingJob(Exception):
    """Define NoTrainingJob Exception.

    It means no Training job has been created by AWS Batch service.
    """

    def __init__(self, value):
        super().__init__(value)
        self.value = value

    def __str__(self):
        """Convert Exception to string.

        Returns: a String containing exception error messages.

        """
        return repr(self.value)


class MissingRequiredArgument(Exception):
    """Define MissingRequiredArgument exception.

    It means some required arguments are missing.
    """

    def __init__(self, value):
        super().__init__(value)
        self.value = value

    def __str__(self):
        """Convert Exception to string.

        Returns: a String containing exception error messages.

        """
        return repr(self.value)
