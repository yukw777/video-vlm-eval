"""The file defines constants used for Batch API helper functions."""

from __future__ import absolute_import

SAGEMAKER_TRAINING = "SAGEMAKER_TRAINING"
DEFAULT_ATTEMPT_DURATION_IN_SECONDS = 86400  # 1 day in seconds.
DEFAULT_TIMEOUT = {"attemptDurationSeconds": DEFAULT_ATTEMPT_DURATION_IN_SECONDS}
POLL_IN_SECONDS = 5
JOB_STATUS_RUNNING = "RUNNING"
JOB_STATUS_COMPLETED = "SUCCEEDED"
JOB_STATUS_FAILED = "FAILED"
DEFAULT_SAGEMAKER_TRAINING_RETRY_CONFIG = {
    "attempts": 1,
    "evaluateOnExit": [
        {
            "action": "RETRY",
            "onStatusReason": "Received status from SageMaker:InternalServerError: "
            "We encountered an internal error. Please try again.",
        },
        {"action": "EXIT", "onStatusReason": "*"},
    ],
}
