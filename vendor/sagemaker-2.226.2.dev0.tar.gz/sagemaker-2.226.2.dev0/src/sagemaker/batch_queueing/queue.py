"""Define Queue class for AWS Batch service"""

from __future__ import absolute_import
from typing import Dict, Optional, List
import logging
from sagemaker.estimator import Estimator, _TrainingJob
from .queue_job import QueuedJob
from .batch_api_helper import submit_service_job, list_service_job
from .exception import MissingRequiredArgument
from .constants import DEFAULT_TIMEOUT, JOB_STATUS_RUNNING


class Queue:
    """Queue class for AWS Batch service

    With this class, customers are able to create a new queue and submit jobs to AWS Batch Service.
    """

    def __init__(self, queue_name: str):
        self.queue_name = queue_name

    def submit(
        self,
        estimator: Estimator,
        inputs,
        job_name: Optional[str] = None,
        retry_config: Optional[Dict] = None,
        priority: Optional[int] = None,
        share_identifier: Optional[str] = None,
        timeout: Optional[Dict] = None,
        tags: Optional[Dict] = None,
        experiment_config: Optional[Dict] = None,
    ) -> QueuedJob:
        """Submit a queued job and return a QueuedJob object.

        Args:
            estimator: Training job estimator object.
            inputs: Training job inputs.
            job_name: Batch job name.
            retry_config: Retry configuration for Batch job.
            priority: Scheduling priority for Batch job.
            share_identifier: Share identifier for Batch job.
            timeout: Timeout configuration for Batch job.
            tags: Tags apply to Batch job. These tags are for Batch job only.
            experiment_config: Experiment management configuration.
                Optionally, the dict can contain four keys:
                'ExperimentName', 'TrialName', 'TrialComponentDisplayName' and 'RunName'.

        Returns: a QueuedJob object with Batch job ARN and job name.

        """
        if experiment_config is None:
            experiment_config = {}
        estimator.prepare_workflow_for_training(job_name)
        training_args = _TrainingJob.get_train_args(estimator, inputs, experiment_config)
        training_payload = estimator.sagemaker_session.get_train_request(**training_args)

        if timeout is None:
            timeout = DEFAULT_TIMEOUT
        if job_name is None:
            job_name = training_payload["trainingJobName"]

        resp = submit_service_job(
            training_payload,
            job_name,
            self.queue_name,
            retry_config,
            priority,
            timeout,
            share_identifier,
            tags,
        )
        if "jobArn" not in resp or "jobName" not in resp:
            raise MissingRequiredArgument(
                "jobArn or jobName is missing in response from Batch submit_service_job API"
            )
        return QueuedJob(resp["jobArn"], resp["jobName"])

    def map(
        self,
        estimator: Estimator,
        inputs,
        job_names: Optional[List[str]] = None,
        retry_config: Optional[Dict] = None,
        priority: Optional[int] = None,
        share_identifier: Optional[str] = None,
        timeout: Optional[Dict] = None,
        tags: Optional[Dict] = None,
        experiment_config: Optional[Dict] = None,
    ) -> List[QueuedJob]:
        """Submit queued jobs to the provided estimator and return a list of QueuedJob objects.

        Args:
            estimator: Training job estimator object.
            inputs: List of Training job inputs.
            job_names: List of Batch job names.
            retry_config: Retry config for the Batch jobs.
            priority: Scheduling priority for the Batch jobs.
            share_identifier: Share identifier for the Batch jobs.
            timeout: Timeout configuration for the Batch jobs.
            tags: Tags apply to Batch job. These tags are for Batch job only.
            experiment_config: Experiment management configuration.
                Optionally, the dict can contain four keys:
                'ExperimentName', 'TrialName', 'TrialComponentDisplayName' and 'RunName'.

        Returns: a list of QueuedJob objects with each Batch job ARN and job name.

        """
        if experiment_config is None:
            experiment_config = {}

        if job_names is not None:
            if len(job_names) != len(inputs):
                raise ValueError(
                    "When specified, the number of job names must match the number of inputs"
                )
        else:
            job_names = [None] * len(inputs)

        queued_batch_job_list = []
        for index, value in enumerate(inputs):
            queued_batch_job = self.submit(
                estimator,
                value,
                job_names[index],
                retry_config,
                priority,
                share_identifier,
                timeout,
                tags,
                experiment_config,
            )
            queued_batch_job_list.append(queued_batch_job)

        return queued_batch_job_list

    def list_jobs(
        self, job_name: Optional[str] = None, status: Optional[str] = JOB_STATUS_RUNNING
    ) -> List[QueuedJob]:
        """List Batch jobs according to job_name or status.

        Args:
            job_name: Batch job name.
            status: Batch job status.

        Returns: A list of QueuedJob.

        """
        filters = None
        if job_name:
            filters = [{"name": "JOB_NAME", "values": [job_name]}]
            status = None  # job_status is ignored when job_name is specified.
        jobs_to_return = []
        next_token = None
        for job_result_dict in list_service_job(self.queue_name, status, filters, next_token):
            for job_result in job_result_dict.get("jobSummaryList", []):
                if "jobArn" in job_result and "jobName" in job_result:
                    jobs_to_return.append(QueuedJob(job_result["jobArn"], job_result["jobName"]))
                else:
                    logging.warning("Missing JobArn or JobName in Batch ListJobs API")
                    continue
        return jobs_to_return

    def get_job(self, job_name):
        """Get a Batch job according to job_name.

        Args:
        job_name: Batch job name.

        Returns: The QueuedJob with name matching job_name.

        """
        jobs_to_return = self.list_jobs(job_name)
        if len(jobs_to_return) == 0:
            raise ValueError(f"Cannot find job: {job_name}")
        return jobs_to_return[0]
